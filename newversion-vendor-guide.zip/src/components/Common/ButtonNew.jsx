const ButtonNew = (props) => {

    return (
        <button {...props} />
    ) 
  }
  
  export default ButtonNew;
  