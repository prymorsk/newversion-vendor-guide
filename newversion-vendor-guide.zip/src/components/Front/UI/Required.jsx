const Required = (props) => {
    return (
        <span className="text-[#c13e27] text-sm font-normal italic ">(Required)</span>
    )
}

export default Required                                                                                                                                                                                                                                                                                                                                                                                                            