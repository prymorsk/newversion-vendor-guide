import RightSideform from "@/components/Front/VendorguideEditlisting/RightSideform"
import RightSidelogo from "@/components/Front/VendorguideEditlisting/RightSidelogo"
const RightSide = (props) =>{
    return(
       <>
       <RightSidelogo/>
       <RightSideform/>
              
       
       </>
    )
}

export default RightSide