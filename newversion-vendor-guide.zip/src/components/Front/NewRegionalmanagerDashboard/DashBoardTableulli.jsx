"use client";
import React from "react";



import TabComponent from "../TabComponent";




  const DashBoardTableulli = (props) => {
   

  
    return(
        <>
            <TabComponent/>
    </>
  );
};

export default DashBoardTableulli;