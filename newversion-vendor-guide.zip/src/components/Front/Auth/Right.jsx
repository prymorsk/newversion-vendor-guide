"use client";
const Right = () => {
    return (
        <div className="md:col-span-1  lg:col-span-1 col-span-12  order-2 sm:order-1 ">
            <div className="bg-[url('/images&icons/loginback.jpg')] h-full bg-cover bg-no-repeat"></div>
        </div>
    )
}

export default Right