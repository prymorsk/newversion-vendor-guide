
import Profilepage from './Profilepage';

export const metadata = {
    title: 'Vendor Guide | Company Profile'
}
  
const Page = () => {
    
    return (
        <Profilepage />
    );
};

export default Page;