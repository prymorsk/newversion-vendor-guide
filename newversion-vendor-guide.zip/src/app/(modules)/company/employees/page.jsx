import Employeepage from "./Employeepage";

export const metadata = {
  title: 'Vendor Guide | Employees'
}

const Employees = () => {
  

  return (
      <Employeepage/>
  );
};

export default Employees;
