export default function CompanyLayout({ children }) {
  return children
}
