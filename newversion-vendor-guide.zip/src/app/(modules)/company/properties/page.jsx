
import Propertypage from "./Propertypage";

export const metadata = {
  title: 'Vendor Guide | Properties'
}

const Properties = () => {
  
  return (
    <Propertypage/>
  );
};

export default Properties;
