import TableData from "./TableData";

const Page = () => {
  return (
    <section className="pt-14">
      <div className="px-10">
          <TableData />
      </div>
    </section>
  );
};

export default Page;
