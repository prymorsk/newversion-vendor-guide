
import Profilepage from './Profilepage';

export const metadata = {
    title: 'Vendor Guide | Profile'
  }

const Page = () => {
    return (
        <Profilepage/>
    );
};

export default Page;