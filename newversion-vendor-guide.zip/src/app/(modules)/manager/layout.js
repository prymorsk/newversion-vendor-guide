export default function ManagerLayout({ children }) {
  return children
}
